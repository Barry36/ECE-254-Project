The multi-project file containing our lab is keil_proc.uvmpw.
To compile, batch build the target "Starter RAM".
To run, start a debug session and connect using TTY to the serial port 115200.